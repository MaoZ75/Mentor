Esercizi carisma
================

Presenza
--------

-  per un minuto osservazione concentrazione su uno dei seguenti:

   -  rumori
   -  dita dei piedi
   -  respirazione

Trasferimento di responsabilità
-------------------------------

ogni volta che in maniera compulsiva il cervello si fissa sulle
conseguenze di una situazione:

-  siediti in una posizione comoda o sdraiati, rilassati e chiudi gli
   occhi
-  fai 3 respiri profondi. inspirando immagina di far affluire aria pura
   alla testa. espirando, lascia che l’aria porti con se tutte le
   preoccupazioni
-  immagina ora di sollevare ciò che ti opprime dalle tue spalle e di
   metterlo sulle spalle dello stregatto. ora tocca a lui.
-  ora che tutto è stato delegato rilassati e goditi ciò che può
   capitarti lungo la strada

Destigmatizzare il disagio
--------------------------

quando un’emozione sgradevole sui fa strada in te ridimensionala con
questo approccio:

-  ricorda che le emozioni sgradevoli sono normali e che tutti le
   provano, prima o poi
-  pensa che altri ci sono già passati, spesso persone molto
   carismatiche
-  ricorda che in questo preciso istante molti altri stanno facendo la
   tua stessa esperienza

neutralizzare la negatività
---------------------------

ogni volta che hai pensieri negativi persistenti:

-  non dare per scontato che corrispondano a verità
-  immagina i tuoi stessi pensieri come graffiti sul muro
-  spersonalizza questo sentimento. osservato come un fenomeno. ditti
   che è interessante,, che stanno emergendo pensieri critici
-  immagina di osservarti dall’esterno. allontana l’obiettivo al punto
   da poter vedere la terra sospesa nello spazio. quindi zumma fino a
   scorgere il tuo piccolo io intento a vivere, in questo preciso
   istante, un’esperienza particolare.
-  immagina il flusso di dialogo nel tuo cervello come se provenisse da
   una radio. Abbassa il volume o sposta la radiolina altrove

Riscrivere la rea
-----------------

Ogni volta che un pensiero fastidioso non ti molla chiediti

-  E se questa situazione fosse una cosa positiva?

Nei casi gravi scrivere di proprio pugno

-  l’incontro é stato un vero trionfo…

ottenere soddisfazione
----------------------

pensa a qualcuno che ti abbia fatto un torto

-  scrivigli una lettera in cui gli dici tutto quel che avrai voluto
   dirgli. a mano
-  una volta scritto tutto dalla mentre sul foglio metti via la lettera
-  pendi un altro foglio intonso e scrivi una lettera in cui
   l’indirizzario della tua si assuma le due responsabilità, ammetta e
   si scusi per tutto il male che ti ha fatto.
-  durante la settimana leggi la lettera di scuse più volte
