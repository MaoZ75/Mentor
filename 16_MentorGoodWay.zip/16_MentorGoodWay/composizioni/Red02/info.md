﻿
# RED Excercises 2

## Riscaldamento

7 minuti. Suggerito 7 minutes workout, in alternativa _MP style_

## Agilità (5 min)

AMRAP (5 min):
- Plank to Teaser X 10
- Switch. Squat X 10
- Hip escape X 10

## Forza (6 min)

- 3X
	- Clean press 90sec
	- Pausa 30sec


## Esercizi dinamici

Tabata 20-10. Due esercizi per 8 volte:

- 8x
	- Mountain Climber
	- Push up con gamba laterale


##Agilità


- _Geko_: Quadrupedia, le ginocchia non toccano terra. Estendi braccio sinistro e gamba destra e viceversa
- _Rollè alto_: Quadrupedia, le ginocchia non toccano terra. Rolle su braccio sinistro e gamba destra. Ruotare fino ad avere il torso in alto e toccare il piede in alto con la mano libera.

## Esercizi dinamici

- Tabata 8X:
	- _switch jump_: 3 switch e salto
	- _squat side to side_: Affondo larerale e salto

## Core

-5x
	-_Planking walk_ (30 sec)
	-_Criss cross to teaser_ (30 sec): Addominali a bicicletta e teaser

## Esecuzione:

Follows the FIT CODE:

Start of the sequence ---------------------------------------;

1. 10;TTS_EN;;default;RED Training 02. For this training you'll need: yourself, something to make a Clean Press
2. 10;TTS_EN;;default;RED Excercises, warm up with 7 minutes workout
1. 30;TTS_EN;;default;Jumping jacks
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Wall sit
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Push-up
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Abdominal crunch
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Step-up onto chair
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Squat
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Triceps dip on chair
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Plank
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;High knees run in place
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Lunge
1. 10;TTS_EN;;default;Now rest
1. 30;TTS_EN;;default;Push-up and rotation
1. 10;TTS_EN;;default;Now rest
1. 15;TTS_EN;;default;Side plank
1. 15;TTS_EN;;default;Change Side
1. 180;TTS_EN;;default;RED, Agility. 10 times each. Plank to Teaser. Switch Squat. Hip Escape.
1. 60;TTS_EN;;default;Two minutes left.
1. 60;TTS_EN;;default;One minutes left.
1. 10;TTS_EN;;default;RED, Forse. Clean Presses
1. 90;TTS_EN;;default;Go, go, go!
1. 30;TTS_EN;;default;Now rest.
1. 90;TTS_EN;;default;Go, go, go!
1. 30;TTS_EN;;default;Now rest.
1. 90;TTS_EN;;default;Go, go, go!
1. 30;TTS_EN;;default;Now rest.
1. 10;TTS_EN;;default;RED, Dinamic Excercices
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;High Mountain Climber.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Push up with lateral, alterned knee touching elbows.
1. 10;TTS_EN;;default;RED, Agility
1. 30;TTS_EN;;default;Geko exercise
1. 30;TTS_EN;;default;Rollè exercise
1. 30;TTS_EN;;default;Geko exercise
1. 30;TTS_EN;;default;Rollè exercise
1. 30;TTS_EN;;default;Geko exercise
1. 30;TTS_EN;;default;Rollè exercise
1. 30;TTS_EN;;default;Geko exercise
1. 30;TTS_EN;;default;Rollè exercise
1. 30;TTS_EN;;default;Geko exercise
1. 30;TTS_EN;;default;Rollè exercise
1. 10;TTS_EN;;default;RED, Agility
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;Now Rest
1. 20;TTS_EN;;default;Switch Jump.
1. 10;TTS_EN;;default;Now rest.
1. 20;TTS_EN;;default;Squat Side To Side.
1. 10;TTS_EN;;default;RED, Core
1. 30;TTS_EN;;default;Plan Walk exercise
1. 30;TTS_EN;;default;Criss Cross to Teaser exercise
1. 30;TTS_EN;;default;Plan Walk exercise
1. 30;TTS_EN;;default;Criss Cross to Teaser exercise
1. 30;TTS_EN;;default;Plan Walk exercise
1. 30;TTS_EN;;default;Criss Cross to Teaser exercise
1. 30;TTS_EN;;default;Plan Walk exercise
1. 30;TTS_EN;;default;Criss Cross to Teaser exercise
1. 30;TTS_EN;;default;Plan Walk exercise
1. 30;TTS_EN;;default;Criss Cross to Teaser exercise
