RED Excercises 2
================

Riscaldamento
-------------

7 minuti. Suggerito 7 minutes workout, in alternativa *MP style*

Agilità (5 min)
---------------

AMRAP (5 min): - Plank to Teaser X 10 - Switch. Squat X 10 - Hip escape
X 10

Forza (6 min)
-------------

-  3X

   -  Clean press 90sec
   -  Pausa 30sec

Esercizi dinamici
-----------------

Tabata 20-10. Due esercizi per 8 volte:

-  8x

   -  Mountain Climber
   -  Push up con gamba laterale

Agilità
-------

-  *Geko*: Quadrupedia, le ginocchia non toccano terra. Estendi braccio
   sinistro e gamba destra e viceversa
-  *Rollè alto*: Quadrupedia, le ginocchia non toccano terra. Rolle su
   braccio sinistro e gamba destra. Ruotare fino ad avere il torso in
   alto e toccare il piede in alto con la mano libera.

Esercizi dinamici
-----------------

-  Tabata 8X:

   -  *switch jump*: 3 switch e salto
   -  *squat side to side*: Affondo larerale e salto

Core
----

-5x -*Planking walk* (30 sec) -*Criss cross to teaser* (30 sec):
Addominali a bicicletta e teaser

Esecuzione:
-----------

Follows the FIT CODE:

Start of the sequence ---------------------------------------;

1.   10;TTS\_EN;;default;RED Training 02. For this training you'll need:
     yourself, something to make a Clean Press
2.   10;TTS\_EN;;default;RED Excercises, warm up with 7 minutes workout
3.   30;TTS\_EN;;default;Jumping jacks
4.   10;TTS\_EN;;default;Now rest
5.   30;TTS\_EN;;default;Wall sit
6.   10;TTS\_EN;;default;Now rest
7.   30;TTS\_EN;;default;Push-up
8.   10;TTS\_EN;;default;Now rest
9.   30;TTS\_EN;;default;Abdominal crunch
10.  10;TTS\_EN;;default;Now rest
11.  30;TTS\_EN;;default;Step-up onto chair
12.  10;TTS\_EN;;default;Now rest
13.  30;TTS\_EN;;default;Squat
14.  10;TTS\_EN;;default;Now rest
15.  30;TTS\_EN;;default;Triceps dip on chair
16.  10;TTS\_EN;;default;Now rest
17.  30;TTS\_EN;;default;Plank
18.  10;TTS\_EN;;default;Now rest
19.  30;TTS\_EN;;default;High knees run in place
20.  10;TTS\_EN;;default;Now rest
21.  30;TTS\_EN;;default;Lunge
22.  10;TTS\_EN;;default;Now rest
23.  30;TTS\_EN;;default;Push-up and rotation
24.  10;TTS\_EN;;default;Now rest
25.  15;TTS\_EN;;default;Side plank
26.  15;TTS\_EN;;default;Change Side
27.  180;TTS\_EN;;default;RED, Agility. 10 times each. Plank to Teaser.
     Switch Squat. Hip Escape.
28.  60;TTS\_EN;;default;Two minutes left.
29.  60;TTS\_EN;;default;One minutes left.
30.  10;TTS\_EN;;default;RED, Forse. Clean Presses
31.  90;TTS\_EN;;default;Go, go, go!
32.  30;TTS\_EN;;default;Now rest.
33.  90;TTS\_EN;;default;Go, go, go!
34.  30;TTS\_EN;;default;Now rest.
35.  90;TTS\_EN;;default;Go, go, go!
36.  30;TTS\_EN;;default;Now rest.
37.  10;TTS\_EN;;default;RED, Dinamic Excercices
38.  20;TTS\_EN;;default;High Mountain Climber.
39.  10;TTS\_EN;;default;Now rest.
40.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
41.  10;TTS\_EN;;default;Now Rest
42.  20;TTS\_EN;;default;High Mountain Climber.
43.  10;TTS\_EN;;default;Now rest.
44.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
45.  10;TTS\_EN;;default;Now Rest
46.  20;TTS\_EN;;default;High Mountain Climber.
47.  10;TTS\_EN;;default;Now rest.
48.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
49.  10;TTS\_EN;;default;Now Rest
50.  20;TTS\_EN;;default;High Mountain Climber.
51.  10;TTS\_EN;;default;Now rest.
52.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
53.  10;TTS\_EN;;default;Now Rest
54.  20;TTS\_EN;;default;High Mountain Climber.
55.  10;TTS\_EN;;default;Now rest.
56.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
57.  10;TTS\_EN;;default;Now Rest
58.  20;TTS\_EN;;default;High Mountain Climber.
59.  10;TTS\_EN;;default;Now rest.
60.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
61.  10;TTS\_EN;;default;Now Rest
62.  20;TTS\_EN;;default;High Mountain Climber.
63.  10;TTS\_EN;;default;Now rest.
64.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
65.  10;TTS\_EN;;default;Now Rest
66.  20;TTS\_EN;;default;High Mountain Climber.
67.  10;TTS\_EN;;default;Now rest.
68.  20;TTS\_EN;;default;Push up with lateral, alterned knee touching
     elbows.
69.  10;TTS\_EN;;default;RED, Agility
70.  30;TTS\_EN;;default;Geko exercise
71.  30;TTS\_EN;;default;Rollè exercise
72.  30;TTS\_EN;;default;Geko exercise
73.  30;TTS\_EN;;default;Rollè exercise
74.  30;TTS\_EN;;default;Geko exercise
75.  30;TTS\_EN;;default;Rollè exercise
76.  30;TTS\_EN;;default;Geko exercise
77.  30;TTS\_EN;;default;Rollè exercise
78.  30;TTS\_EN;;default;Geko exercise
79.  30;TTS\_EN;;default;Rollè exercise
80.  10;TTS\_EN;;default;RED, Agility
81.  20;TTS\_EN;;default;Switch Jump.
82.  10;TTS\_EN;;default;Now rest.
83.  20;TTS\_EN;;default;Squat Side To Side.
84.  10;TTS\_EN;;default;Now Rest
85.  20;TTS\_EN;;default;Switch Jump.
86.  10;TTS\_EN;;default;Now rest.
87.  20;TTS\_EN;;default;Squat Side To Side.
88.  10;TTS\_EN;;default;Now Rest
89.  20;TTS\_EN;;default;Switch Jump.
90.  10;TTS\_EN;;default;Now rest.
91.  20;TTS\_EN;;default;Squat Side To Side.
92.  10;TTS\_EN;;default;Now Rest
93.  20;TTS\_EN;;default;Switch Jump.
94.  10;TTS\_EN;;default;Now rest.
95.  20;TTS\_EN;;default;Squat Side To Side.
96.  10;TTS\_EN;;default;Now Rest
97.  20;TTS\_EN;;default;Switch Jump.
98.  10;TTS\_EN;;default;Now rest.
99.  20;TTS\_EN;;default;Squat Side To Side.
100. 10;TTS\_EN;;default;Now Rest
101. 20;TTS\_EN;;default;Switch Jump.
102. 10;TTS\_EN;;default;Now rest.
103. 20;TTS\_EN;;default;Squat Side To Side.
104. 10;TTS\_EN;;default;Now Rest
105. 20;TTS\_EN;;default;Switch Jump.
106. 10;TTS\_EN;;default;Now rest.
107. 20;TTS\_EN;;default;Squat Side To Side.
108. 10;TTS\_EN;;default;Now Rest
109. 20;TTS\_EN;;default;Switch Jump.
110. 10;TTS\_EN;;default;Now rest.
111. 20;TTS\_EN;;default;Squat Side To Side.
112. 10;TTS\_EN;;default;RED, Core
113. 30;TTS\_EN;;default;Plan Walk exercise
114. 30;TTS\_EN;;default;Criss Cross to Teaser exercise
115. 30;TTS\_EN;;default;Plan Walk exercise
116. 30;TTS\_EN;;default;Criss Cross to Teaser exercise
117. 30;TTS\_EN;;default;Plan Walk exercise
118. 30;TTS\_EN;;default;Criss Cross to Teaser exercise
119. 30;TTS\_EN;;default;Plan Walk exercise
120. 30;TTS\_EN;;default;Criss Cross to Teaser exercise
121. 30;TTS\_EN;;default;Plan Walk exercise
122. 30;TTS\_EN;;default;Criss Cross to Teaser exercise
