7 minutes workout
===========

Here comes the sequence

01. 30;TTS_EN;jumping_jacks.zip;default;Jumping jacks

02. 10;TTS_EN;images/now_rest.png;default;Now rest

03. 30;TTS_EN;wall_sit.png;default;Wall Sit

04. 10;TTS_EN;images/now_rest.png;default;Now rest

05. 30;TTS_EN;push_ups.zip;default;Pushups

06. 10;TTS_EN;images/now_rest.png;default;Now rest

07. 30;TTS_EN;crunches.zip;default;Abdominal Crunches

08. 10;TTS_EN;images/now_rest.png;default;Now rest

09. 30;TTS_EN;step_up_chair.zip;default;Step Up Into a Chair

10. 10;TTS_EN;images/now_rest.png;default;Now rest

11. 30;TTS_EN;air_squat.zip;default;Air Squat

12. 10;TTS_EN;images/now_rest.png;default;Now rest

13. 30;TTS_EN;triceps_chair.zip;default;Triceps Dips on chair

14. 10;TTS_EN;images/now_rest.png;default;Now rest

15. 30;TTS_EN;plank.png;default;Plank

16. 10;TTS_EN;images/now_rest.png;default;Now rest

17. 30;TTS_EN;high_knees.zip;default;High knees run in place

18. 10;TTS_EN;images/now_rest.png;default;Now rest

19. 30;TTS_EN;lunges.zip;default;Lunges

20. 10;TTS_EN;images/now_rest.png;default;Now rest

21. 30;TTS_EN;push_up_rotation.zip;default;Push-up and rotation

22. 10;TTS_EN;images/now_rest.png;default;Now rest

23. 15;TTS_EN;side_plank.png;default;Side Plank

24. 15;TTS_EN;side_plank.png;default;Change Side

